#define FCY 32000000
#include "EEPROM.h"
#include "mcc_generated_files/pin_manager.h"
#include "mcc_generated_files/spi1.h"
#include <libpic30.h>

bool GetRegisterWrite(){
    uint8_t get_status;
    EECS_SetLow();
    SPI1_Exchange8bit(0x5);
    get_status = SPI1_Exchange8bit(0x0);
    EECS_SetHigh();
    return(get_status&0x1);
}

bool WriteByteEeprom(uint8_t add[2], uint8_t* data_to_send){
    uint8_t wr_en = 0x6;
    uint8_t wr_di = 0x4;
    uint8_t data[4];
    uint8_t data_void[4];
    data[0] = 0x02;
    data[1] = add[1];
    data[2] = add[0];
    data[3] = *data_to_send;     
    int i=0;
    EECS_SetLow();
    SPI1_Exchange8bit(wr_en);
    EECS_SetHigh();
    
    EECS_SetLow();
    SPI1_Exchange8bitBuffer(data,4,data_void);
    EECS_SetHigh();
    //for(i = 0 ; i < 10000 ; i++){}
    while(GetRegisterWrite()==true){}
    EECS_SetLow();
    SPI1_Exchange8bit(wr_di);
    EECS_SetHigh();
    
    return true;
    
}


/*bool WriteEeprom(uint8_t add[], uint8_t data_to_send[]){
    uint8_t wr_en = 0x6;
    uint8_t wr_di = 0x4;
    uint8_t data[sizeof(data_to_send)+3];
    uint8_t data_void[sizeof(data_to_send)+3];
    int i =0;
    data[0] = 0x02;
    data[1] = add[0];
    data[2] = add[1];
    for(i = 3 ; i < sizeof(data_to_send)+3; i++){
        data[i] = data_to_send[i-3];
    }       
    
    EECS_SetLow();
    SPI1_Exchange8bit(wr_en);
    EECS_SetHigh();
    
    EECS_SetLow();
    SPI1_Exchange8bitBuffer(data,sizeof(data_to_send),data_void);
    EECS_SetHigh();
    for(i = 0 ; i < 10000 ; i++){}
    //while(GetRegisterWrite()==true){}
    EECS_SetLow();
    SPI1_Exchange8bit(wr_di);
    EECS_SetHigh();
    
    return true;
    
}*/

bool ReadEepromBuffer(uint8_t add[],uint8_t nb_byte_to_read, uint8_t data_to_receiv[]){
    uint8_t to_read[nb_byte_to_read+3];
    int i =0;
    to_read[0] = 0x03;
    to_read[1] = add[1];
    to_read[2] = add[0];
    for(i = 3 ; i < nb_byte_to_read+3;i++){
        to_read[i]=0x0;
    }
    EECS_SetLow();
    SPI1_Exchange8bitBuffer(to_read,4,data_to_receiv);
    EECS_SetHigh();
    return true;
}
