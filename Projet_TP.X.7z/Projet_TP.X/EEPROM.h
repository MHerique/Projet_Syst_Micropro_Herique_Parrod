/* 
 * File:   EEPROM.h
 * Author: mh059444
 *
 * Created on January 12, 2021, 2:24 PM
 */
#ifndef EEPROM_H
#define	EEPROM_H

#include "mcc_generated_files/spi1.h"

#ifdef	__cplusplus
extern "C" {
#endif
    
    bool GetRegisterWrite();
    bool WriteByteEeprom(uint8_t add[2], uint8_t* data_to_send);
    bool ReadEepromBuffer(uint8_t add[],uint8_t nb_byte_to_read, uint8_t data_to_receiv[]);


#ifdef	__cplusplus
}
#endif

#endif	/* EEPROM_H */

