/**
  Generated main.c file from MPLAB Code Configurator

  @Company
    Microchip Technology Inc.

  @File Name
    main.c

  @Summary
    This is the generated main.c using PIC24 / dsPIC33 / PIC32MM MCUs.

  @Description
    This source file provides main entry point for system initialization and application code development.
    Generation Information :
        Product Revision  :  PIC24 / dsPIC33 / PIC32MM MCUs - 1.170.0
        Device            :  PIC24FJ1024GB610
    The generated drivers are tested against the following:
        Compiler          :  XC16 v1.61
        MPLAB 	          :  MPLAB X v5.45
*/

/*
    (c) 2020 Microchip Technology Inc. and its subsidiaries. You may use this
    software and any derivatives exclusively with Microchip products.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION
    WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

    MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE
    TERMS.
*/

/**
  Section: Included Files
*/
#include "mcc_generated_files/system.h"
#include  "lcd.h"
#include "mcc_generated_files/adc1.h"
#include <stdio.h>
#include "mcc_generated_files/rtcc.h"
#include "../Projet_TP.X/mcc_generated_files/pin_manager.h"
#include "mcc_generated_files/spi1.h"
#include "EEPROM.h"
#include "mcc_generated_files/rtcc.h"
#include "mcc_generated_files/../time.h"
#include "mcc_generated_files/tmr2.h"
#include "jeu_du_temps.h"
//#include <stdbool.h>
/*
                         Main application
 */

int mili_secondes;
int secondes;
int difficult = 5;

int main(void)
{
    int out_conversion;
    char affichage[16];
    float temperature_actuel;
    char time_lcd[16];
    uint8_t add_eeprom[2];
    uint8_t add_eeprom_read[2];
    uint8_t data_save;
    uint8_t receiv_eeprom[4];
    int choix_affichage = 0;
    bool clear = false;
    struct tm timer;
    int jouer = 0;
    uint8_t compteur_addresse = 0x10;
    uint8_t compteur_save = 0;
    int moyenne = 0;
    int i=0;
    float tamp_moyenne;
    //int secondes;
    int marge_error = 30 ;
    
    // initialize the device
    SYSTEM_Initialize(); 
    ADC1_SoftwareTriggerEnable();
    add_eeprom_read[1] = 0;
    while (1)
    {
        /*for(i = 0 ; i < 999 ; i++){
            
        }
        ADC1_SoftwareTriggerDisable();*/
        if(ADC1_IsConversionComplete(channel_AN4)){
                out_conversion = ADC1_ConversionResultGet(channel_AN4); 
                temperature_actuel = ((-40)+(((out_conversion*3.22)-100)/10));
                //
                //LCDHome();
                //
                AD1CON1bits.DONE = false;
        }
        
        if(compteur_save == 75){            
            add_eeprom[0] = compteur_addresse;
            add_eeprom[1] = 0x00;
            data_save = (uint8_t)temperature_actuel;
            WriteByteEeprom(add_eeprom, &data_save);
            if(compteur_addresse >= 0x1F){
                compteur_addresse = 0x10;
            }
            else{
                compteur_addresse++;
            }

            //ReadEepromBuffer(add_eeprom,1,receiv_eeprom);
            compteur_save = 0;
        }
        else{
            compteur_save++;
        }
        
        if(Buton_S3_GetValue()==0){
            choix_affichage++;
            clear = false;
            jouer = 0;
            while(Buton_S3_GetValue()==0);
        }
        
        if(clear == false){
            clearLCD();
            clear = true;
        }
       
        switch(choix_affichage){
            case 0 :
                LCDHome();
                putsLCD_b("Naviguez dans   ");
                newLine();
                putsLCD_b("les menu avec S3");
                break;
            case 1 :
                LCDHome();
                RTCC_TimeGet(&timer);
                sprintf(affichage,"Date : %i/%i/%i ",timer.tm_mday,timer.tm_mon,timer.tm_year );
                putsLCD_b(affichage);
                newLine();
                sprintf(affichage,"Heure: %i:%i:%i  ",timer.tm_hour, timer.tm_min,timer.tm_sec );
                putsLCD_b(affichage);
                break;
            case 2 :
                LCDHome();
                sprintf(affichage,"Temp : %.1f C",temperature_actuel );
                putsLCD_b(affichage);
                add_eeprom_read[0]=0x10;
                for(i=0x10; i < 0x1A;i++){
                    add_eeprom_read[0]=i;
                    ReadEepromBuffer(add_eeprom_read,1,receiv_eeprom);
                    moyenne+=receiv_eeprom[3]; 
                }
                tamp_moyenne=moyenne/10;
                sprintf(affichage,"moyenne : %.1f",tamp_moyenne);
                moyenne = 0;
                newLine();
                putsLCD_b(affichage);
                break;
            case 3 :
                if((Buton_S6_GetValue()==0) && (jouer == 0)){
                    difficult = 7;
                    LCDHome();
                    sprintf(affichage,"Difficulte max ");
                    putsLCD_b(affichage);
                    while(Buton_S4_GetValue()==0);
                }
                if((Buton_S5_GetValue()==0) && (jouer==0)){
                    difficult = 5;
                    LCDHome();
                    sprintf(affichage,"Difficulte min ");
                    putsLCD_b(affichage);
                    while(Buton_S4_GetValue()==0);
                }
                
                if(jouer == 0){
                    LCDHome();
                    sprintf(affichage,"Pressez S4 pour ");
                    putsLCD_b(affichage);
                    sprintf(affichage,"lancer la partie");
                    newLine();
                    putsLCD_b(affichage);
                    if(Buton_S4_GetValue()==0){
                        jouer = 1;
                        mili_secondes = 0;
                        secondes = 11;
                        clear = false;
                        while(Buton_S4_GetValue()==0);
                        TMR2_Start();
                    }
                }
                else {
                   if(jouer == 2){
                        if(Buton_S4_GetValue()==0){
                            jouer = 0;
                            while(Buton_S4_GetValue()==0);
                        }
                    }
                    else{
                        jeu();
                        if((secondes==0) && (mili_secondes == 0)){
                            TMR2_Stop();
                            jouer = 2;
                            clearLCD();
                            sprintf(affichage,"  %i:%i   ",secondes,mili_secondes);
                            putsLCD_b(affichage);
                            sprintf(affichage,"Vous avez perdu");
                            newLine();
                            putsLCD_b(affichage);
                        }
                        else if(Buton_S4_GetValue()==0){
                            TMR2_Stop();
                             jouer = 2;
                             while(Buton_S4_GetValue()==0);
                             if((secondes==0) && (mili_secondes < marge_error)){
                                 clearLCD();
                                sprintf(affichage,"  %i:%i   ",secondes,mili_secondes);
                                putsLCD_b(affichage);
                                 sprintf(affichage,"Vous avez gagne");
                                 newLine();
                                 putsLCD_b(affichage);
                            }
                            else{
                                clearLCD();
                                sprintf(affichage,"  %i:%i   ",secondes,mili_secondes);
                                putsLCD_b(affichage);
                                sprintf(affichage,"Vous avez perdu");
                                newLine();
                                putsLCD_b(affichage);
                            }
                        }
                    }
                }
                
                break;
            default:
                choix_affichage = 0;        
        }
              
    }

    return 1;
}
/**
 End of File
*/

