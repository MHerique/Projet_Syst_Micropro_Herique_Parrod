/* 
 * File:   ldc.h
 * Author: Mathieu_H
 *
 * Created on 1 d�cembre 2020, 16:53
 */

#ifndef LDC_H
#define	LDC_H

#ifdef	__cplusplus
extern "C" {
#endif

#include <xc.h>

void InitLCD_b( void);

void PutLCD_b(char kar);

void putsLCD_b( char *s);

void newLine();


void LCDHome();

void clearLCD();

#define PMDATA  PORTE



#ifdef	__cplusplus
}
#endif

#endif	/* LDC_H */

