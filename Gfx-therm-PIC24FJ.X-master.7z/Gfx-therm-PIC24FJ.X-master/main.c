/*******************************************************************************
 Microchip Graphics Library Application Demo

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    Application demo for Graphics Library Primitive Layer.

  Description:
    This demo shows the Primitive Layer rendering features of the Microchip
    Graphics Library.
*******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*******************************************************************************/
// DOM-IGNORE-END

// *****************************************************************************
// Section: Includes
// *****************************************************************************
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include "system.h"
#include "mcc_generated_files/system.h"
#include "gfx/gfx.h"
#include "gfx/gfx_colors_x11.h"
#include "gfx/gfx_gol.h"
#include "gfx/gfx_gol_button.h"
#include "internal_resource.h"
#include "mcc_generated_files/adc1.h"
#include "lcd.h"
#include "EEPROM.h"
#include "mcc_generated_files/rtcc.h"
#include "mcc_generated_files/pin_manager.h"
#include "../jeu_du_temps.h"
// *****************************************************************************
// Section: Function Prototypes
// *****************************************************************************


bool APP_ObjectDrawCallback(void);

// *****************************************************************************
// Section: Macros
// *****************************************************************************
#define APP_WaitUntilFinished(x)    while(!x)
// *****************************************************************************
// Section: Defines
// *****************************************************************************
#define APP_SCREEN_DELAY_MS         (1000)
// *****************************************************************************
// Section: Constants

// *****************************************************************************

// *****************************************************************************
// int main(void)
// *****************************************************************************

int mili_secondes;
int secondes;
int difficult = 5;

int main(void)
{   char affichage[16];
    int out_conversion;
    int compteur_save = 0;
    float temperature_actuel;
    uint8_t add_eeprom[2];
    uint8_t add_eeprom_read[2];
    uint8_t data_save;
    uint8_t receiv_eeprom[4];
    int compteur_addresse = 0X10;
    int moyenne = 0;
    int i=0;
    float tamp_moyenne;
    int compteur_affichage =900;
    char affichage_bienvenu[53] = "Bienvenu dans notre un peu moche interface graphique";
    int en_jeu = 0;
    char vider[15] = "               ";
    char affichage_jdt[50] = "Appuyez sur S4 pour arreter � 0.";
    char gagne[30] = "Vous avez gagne (S3 pour r�initialiser)";
    char perdu[30] = "Vous avez perdu (S3 pour r�initialiser)";
    
    // initialize the device
    struct tm timer;
    SYSTEM_Initialize();
    // initialize hardware components and peripherals
    SYSTEM_BoardInitialize();
    //ADC1_Initialize();
    GFX_Initialize();
    
    
    GFX_ColorSet(WHITE);
    GFX_ScreenClear();
    /*GFX_LineStyleSet(GFX_LINE_STYLE_THICK_SOLID);
    GFX_ColorSet(RED);
    GFX_LineDraw(0,120,60,120);*/
    
    
    
    GFX_FontSet((GFX_RESOURCE_HDR*) &Font25);
    GFX_TextStringDraw(100,120, (char*)affichage,0);
    
    ADC1_Initialize();
    // Turn on the display backlight.
    // this is called here so we do not see the screen in a state
    // where the display buffer has not been initialized
    DisplayBacklightOn();
    ADC1_Initialize();
    ADC1_Enable();
    ADC1_Start();
    ADC1_SoftwareTriggerEnable();
    ADC1_ChannelSelect(channel_AN4);
                

    while(1)
    {   
        
        
        
        if(ADC1_IsConversionComplete(channel_AN4)){
            out_conversion = ADC1_ConversionResultGet(channel_AN4); 
            temperature_actuel = ((-40)+(((out_conversion*3.22)-100)/10));
            ADC1_SoftwareTriggerDisable();
                //
                //LCDHome();
                //
                //AD1CON1bits.DONE = false;
        }
        // RTCC
        
        GFX_ColorSet(WHITE);
        GFX_ColorSet(BLACK);
        RTCC_TimeGet(&timer);
        if(compteur_affichage == 2000){
            GFX_TextStringDraw(80,5, (char*)affichage_bienvenu,0);
            sprintf(affichage,"Date du jour : %i/%i/%i ",timer.tm_mday,timer.tm_mon,timer.tm_year );
            GFX_TextStringDraw(50,25, (char*)affichage,0);
            sprintf(affichage,"Heure: %i:%i:%i  ",timer.tm_hour, timer.tm_min,timer.tm_sec );
            GFX_TextStringDraw(50,45, (char*)affichage,0);
            compteur_affichage=0;
        }
        else{
            compteur_affichage++;
        }
        //
        
        if(compteur_save == 5){            
            add_eeprom[0] = compteur_addresse;
            add_eeprom[1] = 0x00;
            data_save = (uint8_t)temperature_actuel;
            WriteByteEeprom(add_eeprom, &data_save);
            if(compteur_addresse >= 0x1F){
                compteur_addresse = 0x10;
            }
            else{
                compteur_addresse++;
            }

            //ReadEepromBuffer(add_eeprom,1,receiv_eeprom);
            compteur_save = 0;
        }
        else{
            compteur_save++;
        }
        
        add_eeprom_read[0]=0x10;
        moyenne = 0;
        for(i=0x10; i < 0x11;i++){
            add_eeprom_read[0]=i;
            ReadEepromBuffer(add_eeprom_read,1,receiv_eeprom);
            moyenne+=receiv_eeprom[3]; 
        }
        tamp_moyenne=moyenne;
        
        sprintf(affichage,"Temp : %.1f C",tamp_moyenne );
        //GFX_ColorSet(WHITE);
        //GFX_ScreenClear();
        if(compteur_affichage == 2000){
            GFX_ColorSet(WHITE);
            GFX_ScreenClear();
            GFX_ColorSet(BLACK);
            GFX_TextStringDraw(250,150, (char*)affichage,0);
        }
        
        if(Bouton_S3_GetValue()==0){
            if(en_jeu == 2 ){
                en_jeu=0;
            }
            else{
                en_jeu = 1;
            }
            initJeu();
            while(Bouton_S3_GetValue()==0);
        }
        
        if(Bouton_S4_GetValue()==0){
            en_jeu = 2;
            initJeu();
            while(Bouton_S3_GetValue()==0);
        }
        
        if(compteur_affichage%1000==0){
            
            if(en_jeu == 0){
                sprintf(affichage,"Appuyez sur S3 pour commencer � jouer",secondes,mili_secondes);
                GFX_TextStringDraw(40,240, (char*)affichage,0);
            }
            if(en_jeu == 1){
                GFX_ColorSet(WHITE);
                GFX_ScreenClear();
                GFX_ColorSet(BLACK);
                GFX_TextStringDraw(40,200, (char*)affichage_jdt,0);
                if((secondes == 0 ) && mili_secondes == 0){
                    en_jeu = 3;
                }
                else if(secondes > 4){
                    //GFX_TextStringDraw(40,240, (char*)vider,0);
                    sprintf(affichage,"Jeu du temps : %i:%i ",secondes,mili_secondes);
                    GFX_TextStringDraw(40,240, (char*)affichage,0);
                }  
            }
            if(en_jeu == 2){
                GFX_ColorSet(WHITE);
                    GFX_ScreenClear();
                    GFX_ColorSet(BLACK);
                if(secondes == 0){
                    GFX_TextStringDraw(40,200, (char*)gagne,0);
                }
                else{
                   
                    GFX_TextStringDraw(40,200, (char*)perdu,0); 
                }
                    secondes = 10;
            }
            if(en_jeu == 3){
                GFX_ColorSet(WHITE);
                GFX_ScreenClear();
                GFX_ColorSet(BLACK);
                    GFX_TextStringDraw(40,200, (char*)perdu,0); 
            }
            
        }
        
        
        /*GFX_ColorSet(BLUE);
        GFX_RectangleRoundDraw(0,0,480,20,8);
        GFX_ColorSet(GFX_RGBConvert(0, 0, 40));
        GFX_RectangleRoundFillDraw(0,0,480,20,8);*/

    }
}
