# Base project to use Microchip GOL with Explorer 16/32 PIC24FJ1024GB610, SSD1926 and Graphics Display Powertip 4.3in. 480x272 Board 
