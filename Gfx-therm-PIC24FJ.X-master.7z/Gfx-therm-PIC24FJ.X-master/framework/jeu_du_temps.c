#include "jeu_du_temps.h"
#include "lcd.h"
#include <stdio.h>

void initJeu(){
   mili_secondes = 0;
   secondes = 9;
}

void jeu(){
    char affichage[16];
    LCDHome();
    if(secondes > difficult ){
        sprintf(affichage,"  %i:%i   ",secondes,mili_secondes);
        putsLCD_b(affichage);
    }
    else{
        sprintf(affichage,"  ??:??  ");
        putsLCD_b(affichage);
        newLine();
        sprintf(affichage,"touche arret S4");
        putsLCD_b(affichage);
    }
    
    
}


