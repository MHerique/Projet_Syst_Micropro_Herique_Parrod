/* 
 * File:   jeu_du_temps.h
 * Author: mh059444
 *
 * Created on 18 janvier 2021, 11:06
 */

#ifndef JEU_DU_TEMPS_H
#define	JEU_DU_TEMPS_H
extern int mili_secondes; // pour jeu du temps
extern int secondes;
extern int difficult;
#ifdef	__cplusplus
extern "C" {
#endif

    void initJeu();
    void jeu();
    


#ifdef	__cplusplus
}
#endif

#endif	/* JEU_DU_TEMPS_H */

