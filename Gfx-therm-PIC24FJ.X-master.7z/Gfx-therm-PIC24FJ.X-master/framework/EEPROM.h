/* 
 * File:   EEPROM.h
 * Author: mh059444
 *
 * Created on 18 janvier 2021, 11:07
 */

#ifndef EEPROM_H
#define	EEPROM_H

#include "mcc_generated_files/spi1.h"

#ifdef	__cplusplus
extern "C" {
#endif
    
    bool GetRegisterWrite();
    bool WriteByteEeprom(uint8_t add[2], uint8_t* data_to_send);
    bool ReadEepromBuffer(uint8_t add[],uint8_t nb_byte_to_read, uint8_t data_to_receiv[]);


#ifdef	__cplusplus
}
#endif

#endif	/* EEPROM_H */

